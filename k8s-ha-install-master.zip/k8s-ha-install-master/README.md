```

  安装文档:https://www.cnblogs.com/dukuan
  
```

# 超全面、超详细的Kubernetes视频教程，基于最新K8s进行讲解
http://www.kubeasy.com/

咨询QQ727585266
